# Soal UAS - Web News and Blog

## Desktop Page

### index.html

![](index-desktop.png)

### article.html

![](article-desktop.png)

## Mobile Page

### index.html

![](index-mobile.png)

### article.html

![](article-mobile.png)

## Form Pengumpulan

[https://docs.google.com/forms/d/e/1FAIpQLSdzZy1PinsHaxUPB6kcm-lOzOp3KuHqshd-xfmlbwiemZrBlA/viewform?usp=dialog](https://docs.google.com/forms/d/e/1FAIpQLSdzZy1PinsHaxUPB6kcm-lOzOp3KuHqshd-xfmlbwiemZrBlA/viewform?usp=dialog)
